import React from "react"
import Etiqueta from "./components/Card";
import "./components/Card/index.module.css"

function App() {
    return (
        <div className="app-container">
            <Etiqueta>
                <h2>Tarea 1</h2>
                <p>Pasear al perro</p>
                <p><strong>Asignado a:</strong>Martina</p>
                <p><strong>Fecha de inicio</strong>2024-09-15</p>
                <p><strong>Fecha de cierre:</strong>2024-09-20</p>
            </Etiqueta>
            <Etiqueta>
                <h2>Tarea 2</h2>
                <p>Ir al gimnasio</p>
                <p><strong>Asignado a:</strong>Felipe</p>
                <p><strong>Fecha de inicio</strong>2024-09-16</p>
                <p><strong>Fecha de cierre:</strong>2024-09-21</p>
            </Etiqueta>
            <Etiqueta>
                <h2>Tarea 3</h2>
                <p>Salir a correr</p>
                <p><strong>Asignado a:</strong>Juan</p>
                <p><strong>Fecha de inicio</strong>2024-09-17</p>
                <p><strong>Fecha de cierre:</strong>2024-09-22</p>
            </Etiqueta>
        </div>
    );
}

export default App;
